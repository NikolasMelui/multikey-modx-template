<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd1e6559cf2987fd37125c126ea0e9006',
      'native_key' => 'core',
      'filename' => 'modNamespace/f4fabe48d419669cacdfdedbfd3a818b.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '40692a5c02a058c000377c269dcabd2e',
      'native_key' => 1,
      'filename' => 'modWorkspace/6a31db2d46eea397d74f07a28d2888d9.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'fda7a31ea981e5c68eb0dba24c3a2341',
      'native_key' => 1,
      'filename' => 'modTransportProvider/49b6be82a7bc97a1a8fc3b4196add550.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8632200eb5b8d85424441573f7fe6ed4',
      'native_key' => 'topnav',
      'filename' => 'modMenu/2e40b58697777d1753d6613e8e70a5db.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '363ef2818380c2b30829db3b61a55b65',
      'native_key' => 'usernav',
      'filename' => 'modMenu/1a1ddf5a909167c269432162adea8f1a.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '88e5402055b51725c46cb7a0b515ad95',
      'native_key' => 1,
      'filename' => 'modContentType/d94c57b5861915ebd00ef8428d3def34.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'da5a27fed8b3ab90ece4c280193e9bc5',
      'native_key' => 2,
      'filename' => 'modContentType/e238ee0ee9089702572099a7e27d1656.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '79f62bec92100da59ecb78783e2506f9',
      'native_key' => 3,
      'filename' => 'modContentType/166834bde0a8b5b749432b3cc6fe64b1.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3a5f706636a411511159a0eb605200e8',
      'native_key' => 4,
      'filename' => 'modContentType/07b62bcfc2e5f3c9ffcb44c381ff6453.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a7e0ddc6cc878d79afd5f3d88b6dfd36',
      'native_key' => 5,
      'filename' => 'modContentType/00cfa9fb98e63ca6d97b51c27528b41d.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f894d2be096c2c8d8538d93c3f4c9c2d',
      'native_key' => 6,
      'filename' => 'modContentType/026a78c17eeb95d71c6adee21d6a2844.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '147627200ccfc076fd804abb7bb51e05',
      'native_key' => 7,
      'filename' => 'modContentType/2da08e30b690eb2d76bee31bffe382bf.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ce8516b7d507272aa2de3ed378549a8c',
      'native_key' => 8,
      'filename' => 'modContentType/38df5a508c986fa3510dcb6c603da006.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f889cc4f9ab9bbdf1ab68d325e6d3947',
      'native_key' => NULL,
      'filename' => 'modClassMap/db172685682a3674354c6761cf825555.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b968d20f151d06cc12b6d9915b6b8c72',
      'native_key' => NULL,
      'filename' => 'modClassMap/bed5c3f79051f73ef591f1569e4f28c1.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '289d80ba68baca67ba4438b7fcd6dfcb',
      'native_key' => NULL,
      'filename' => 'modClassMap/cad5d2745338836778913481d692eb37.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7d0af99b3b23df47adfcd3b8da5de453',
      'native_key' => NULL,
      'filename' => 'modClassMap/4dc9bff12bf0ef3d5aba98aaa11de061.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8f185513f67c9f926c72f03f4a38e2bc',
      'native_key' => NULL,
      'filename' => 'modClassMap/943b300ca994469170b000a97c99746f.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '11be682c65fc8b79ffb6b0203a883fd7',
      'native_key' => NULL,
      'filename' => 'modClassMap/84ca2b840903f0a63d0c807c29dbee9d.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '98f19a8600120866a771ff81edb91c49',
      'native_key' => NULL,
      'filename' => 'modClassMap/286d09b0eaec824bf4f30166b8044803.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '72247b2b3c96de6749ab9d50499e143c',
      'native_key' => NULL,
      'filename' => 'modClassMap/081c5bd953c4237640b4d13d35305cd3.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2b20d40125b5280d0c4bb8dc36dd1fad',
      'native_key' => NULL,
      'filename' => 'modClassMap/14e2621ca9264789a3bdb2f372c3cd9f.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de30e1ad36976349023b5eb4dadccf7d',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/af58272288c9ad6139dfd9c84594e4be.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb28f22c2331d1ec756a57d676698ce6',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/3192c35d91bf433dbe5cc0eddb33c5be.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc072ad069eb6ca4d13ff394912f1637',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/9421401f51c3250727e432e24e27be06.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '201ba3ee934347e75bcfbfdfd546d689',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/88172ee14df3a13dead56cebd82e6a2e.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccfb7b3884eb0c2d8e6ad0cb6203a0c3',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/ebfbf960ad910d382ece93a056d1bbbb.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b97ad36823f9a14c667a4f91d66a8e7f',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/1d4b0d2fb9adf98a537ef41d60ed3829.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f193ea826aecc5f17487d72529139ea',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/3d9a555b9b611d92d5cec4522b7d99a9.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1db2ede29827c81d8e842291ebd60643',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/bd6b5e97999815b27af6828cca5a8ba9.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05a402a8467c9083c9471ae79d3fc872',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/72223eb3152d33c44544e1f30e20059c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd510c9e5fcbeb323aa80025800c0893a',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/4d56b815c05329e6c5c8c8b2c2586b39.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a020f6e2333529c7643dc6a75f02b6d2',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/852a8bd3a787bb20e2087c3a2a9505fd.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81664f247fefb1a028da0c65cb9196f1',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/e575176c6428fdb837d68465b294f8b7.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6145e854465146ac266a07af74efe11',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/7d1e15bc50974d8271e8e7929dbb3de6.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '015cf5b690c730a7914b2c0d9690d241',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/f52599773629652860a92663a03d4ef3.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fddc4038df57ab7362d55be2aaa12d2f',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/07cc3782e75fbd2daa25f99e93086a99.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0be2ee9d2245341c609872cb0831a733',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/edefcd09349d5fd1555dbc793181b992.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b93f72e065288a084967f0beabb19fa1',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/c383070b1da3f2aed58299553e88392f.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28e41fe3854ad7880010fdca8a66565f',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/e352900883bafa1997dc12ad78c8dc22.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99763234cc6ef7aa4d64dfedd6f2f7e7',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/071e0ea7b9a31c2701359fc124c99cb7.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40ac9578e039c1596c1a2b630d4859b5',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/99422a49ef5289eda73341f5432cf121.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd020d74a3f8c8fd59a5f33c0aa1cc3fa',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/6b6156e723cdbbe8b5b3299ece2231cd.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b347144facc4e49c4f31dc2f08c24f1',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/ddb8c3de12988e3945237fa9ee2cc17d.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a40ef8dbfff63884d792ffcb999bad82',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/e63ef84dca8232c6f0b32647c3299866.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b506cf5e9befa2e14d30291a7b888844',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/0afba2cd3837169f7eb4a7667c1b7306.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0111213f16f06ae41bba03990f95c2e',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/f80af8b1ef8e9e50235c36338da984fb.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd23659978949f81671497a5c9bbc88e1',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/4f0835220715212e6d7b4678aee54cf3.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '543fb5f0c12c53c4a34bbd02209494b8',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/9e8e3fdd92627a9b564a2da2056639ed.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5221bc1a236eb82830d623323b125a9c',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/9bcb1fe3c7777ad300ff0294a3f692dd.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d35abc7d73c676a533ba507a4f8cba3',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/b275f932d67b97dee9c508cb4b9a918a.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5813a1ca52c515a25546313d70e3ea57',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/e054103171a34e4dfe9f3fa89c1409b6.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '516d375783bec6f3466d61ba731fa81c',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/b3f46b12b5fa1da9fb063a04a5647be4.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e32756990ba8ce1d4a51647369c4037',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/fa41d5b4d6434dd73837b0dc61d8c30b.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd03d0b2282b303104a4271339dfea3ff',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/0a914e7091d64d2d748029c117cc3d96.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c63161fc5d9dd8dd448ba589c349b53',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/c05d0c313937a7725100119ab8661735.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d726aa3c154aa9cd1e4a5999f3110da',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/a8c0aafb553600e71baf49246a321f73.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12c2eeb4c5d3ddc0b8ffc5a46dd7dbde',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/cead0dbaf0fd1ddfd0bb968a755a0c06.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4c215ff6e028b3465a163a42ab11b9a',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/e51ac5803b5d9b68d7b98faf0049060e.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28293f8c33565ad3ed54fa11a12a69d9',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/75431419888af1e4161a9eff8bf9bcf3.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf67f5fd87bfdabf4041a2537e093f25',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/c4e467c50621ec541dabc9f0b605f321.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9efedee65ea1abd1412d7fd4b50907aa',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/44eb5f19b5ff567ee0998635a5dfe7d4.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c5c2a1866e44f3c5ff325be74dbbd21',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/e5513f35501ce2ef69c87eebac8e8592.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e19ee9d049425ea2197b0818c6311648',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/139d740714f5d3d5a987d05a8b03baa0.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90b86c9b0bb592639f8b89cb6be059d3',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/c28128b8f12a75638c0beced758cff90.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21a525cc0d4898f2a1b56c59fd9ba7d9',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/5ed895774848650eac918516ccbb7126.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cb3f0aa11af0d2e165eff068427f1c4',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/c5ba7b4850801be6b4bcf7f102d8cc35.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd92e1424aebe39104245ea070bbdf6c8',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/71d2c528b1026ea5929f2252c1f0ac93.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa2e029e17eb0faabdb710a878a82d1a',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/074613d8749c5385aab4386825f8dbaa.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e25fbc3b1d01cde986b7594a7512a15',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/3ac39e1396f2d2637a15fefa69575428.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '689dbc43ef6f683c7cb0aec60890ec26',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/c80d81ea769522559422dd27627a2b53.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '786f1f54f8687b7c552f1d41fdf49fd9',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/18e5433fd62c70ec2aa3d6f1fc576899.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4d48fd4e628bc5ec4fe2b13f9b93a45',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/02159d00ec95d53048a82bf044c6d694.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eef5124f14107c92d8e41ba1c92ca68b',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/37291400e51171b513508ff3790d6f37.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48def7da13cc4fa5f8dad8ac1da1e087',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/58195d59937feef29ab670048aee48f0.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc241834c77394009f658d5d8bc53b77',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/ad2624ccb81638f4932357e89fc609dc.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4571b930941511281ea0f56bc54059b',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/42539f14776f16904fa15fdf08a3494e.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3df3613857aa2fae80823e3ea9e2d58c',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/210968a4813a73a853647e355aa7135b.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '857dfc02f79bb035ce3aa4393b36256f',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/7878c684e46d85086a4fe07e55faffd2.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fa0bd49eae4d90da39a82a69b2b17a7',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/bb5b83f5097901ce604e682e7ed5143e.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '062eb3adf0f36c9972be1de072d096d4',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/846c900cee23e6165cd312c8f68a3be8.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de45039d4ea1dc7b61eb6ed1300983d1',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/279b662908cfc551ce47a6d2dc687b25.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38e69847306b282b12b15efb02554f1d',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/a3dfccee4f02671893faf60388bed5b9.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38c6e6c93346a943c6f3bdba9165cbc0',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/95f1d01f5ed636015ecca471ad082c99.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fd1e545fa1be0c6359278a2f69454f7',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/6fb260a84fe85fea742a7ff45a65d809.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a5a5080ef44936e01b8a47a1ac11859',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/91e0810334db1dac177aa86b0eabb259.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6cf1ecc968982b8aeee570c769f34b2',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/36569af8493dfa93958dbb2dd1a2dc4f.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10e81c89771800cc474edaa7630a9eba',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/a8ba4c4fe20f7bb9519e3800a1240e1c.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d6f4d43ee5df407b816d57deb0bf6bc',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/f656e688672896283eb1a715ea51f3d1.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13e470f49957a68e79b28d6397dba45a',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/64ffb58151c2aa05bc7ee16f20cf8323.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b653e48b8d08ac89dd359ed6f13c81f',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/931bf28935cc0088ab4e2623f91edfc2.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2296a1a988d8a3a299b268ce8e483b9',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ce1ddd4b80bc0f6b7641652ec11b0750.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0fb47b433b7c04a51a88d1c8be7de19',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/6fd41e82bebeaabab4d51c705b0d28c2.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f887c37ccd7b2a03069d28d43790acf',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/45936085eb5213473bf681cadd88101a.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db88c8567f515b5e9db38060d67c0d96',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/9fcbc3df1a7dc61a80e4d825add7b0a1.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '407a549e6ccbbdfedd7f0799e0edd861',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/d33a2ea075a58e882cf482a3b47e1179.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b87dcbe67a33b6fefa3f80da489b1578',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/2a312460c73387ee7e426f23cd3dfa19.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '080b551d71cb9968eeb860c0d2919017',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/3ef4ec6a1c844617d6760a59e9307bb6.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f29a21095405e295108fb8a3123da24c',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/19281771b755e910fce77e133c88fe3b.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74e21d145ccf2a415649e1289ac75c8f',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/78e685ca9c1d1a35ef176d3dab6ece54.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c44dd1336de983f31d9bca6e838bf2ac',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/9709bc1fe5e256868891d95317defa0e.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '589e6ed7d1d889136db973bdd337a562',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/62500e2bbfb75d171eb763b4de1a4094.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abaad7363a4d249993bd90a72394b4f8',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/ec1ea7d57e4d3e913aae01969f6ac684.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'faaff1661026813b93fe7a2ed7c727ea',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/710f280f2aa010dbfb0d056c2407392c.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '206849e493c1f84016efce5949bf3d50',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/68439889c00e5cc4bde626bdbdbbad68.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96aac0c3aa813db4f1006a559e8da609',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/b8aa107a75d6f67864ac0961a5e04858.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9550745be63d0ab157ecbed824f6258',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/2aab179eead64fdc092805ff5c256f92.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d49ff09a352fd2b59069d8a9560407c',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/bad782c05cc23430e1df36df574b4713.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'baf442e11dd0a15d292bf9f4aa46f804',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/dd270f5843fea9a5adb30f0df6a26558.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1054b9f422d4418495ee6a8c523d53d',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/5cc4fe34098144c481eee125c357d3bf.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e2c95b4f89076cf1222ff89ed03fc53',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/434e13eee3a29a863bc72b32e3a98009.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '877f3701d3802870eaf4617a39d13164',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/0fc1f09d99703332fbbc737810f8875c.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a78c8b41ee38b6d62d4ad7f2d395e702',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/270fb3011d059fd0d31b8fe155947166.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9cd74b6e2b9a5fbb0eecc1af2532899',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/f8aedb7fd9f9a07c5e5ca9ce19ac335d.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3d092147ad72de528b13f1d3c9de20f',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/47a9b6c3d4721481a8ec52ce0cda38a4.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cc2e73dc0bb41070521f175c367f3f3',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/2e4f351190ea2ae2b4c3db554c8209da.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4928f01dee7ac61e9ca46c7c15ac47b',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/cfa6b5e23f61beba5b87c9131eb363e1.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f72a4deaa078ec7656106bed83cdeee8',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/13492045f147e5dc60a7b2464c134f03.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd83c6fd1cd35b1f854fab443b5299cae',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/5424bf878afbdb0795f14b6b6373a5f8.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0a416cf457818a973696ba190803ec1',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/eb0169a89b72fab11c97f5e1315f0f04.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42c7d03157c4cf57dbb4463e80c5b3b1',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/fd18208be6e70263aae941b2ea368e75.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d50cad007b99c9637f60a5ed099149c',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/e045773a422e52e421e546ab51971c07.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '934edb11a82b225db89a5bec51765b1f',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/a5f3e96809469b94879e703cda30fd99.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5c9949cf86677331b8c196b3bfabdfa',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/6835b8715cc220c7ec5e7dd90074bf58.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46884e5e8855c03daa3cded578160f96',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/79bfbf8402054748e1581e14d59c46b8.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88a1d6885a4eea76315a064236b904bb',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/1e2327cfb764c1e339194bac276db783.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b5f695a59c4b29ad47fb7905d7b215a',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/6859bcb8a4442678e35b706e47397131.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52b65c15be677a8bad391eabc22a4c23',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/3ff9e8aed6c0d41296ef2ad529a4ceba.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99877b43c628f6a69d16462688b07484',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/65cbc9e7b1890de550eb5c9f89cb12b2.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07fa974941e8c965503fd8e66e2c6fd8',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/a8e93e405268077234c4b1e600d50c1c.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44f73683caf857332959d69718df3d0d',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/7eb0c75586c26e8e2b6a62e5851c0d88.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c45df0f4c3d88d34e645b3b77cb5e088',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/e14f546820af2d083a660d574215e767.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1bb271a7712856e43ba1f628f165877',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/f8698e21594657532a28547d035badc6.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53bbf1f6fc3cf18e20db0d7c3eebd6c0',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/3764bc727ddaad897f241382c342e12e.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f760e2861f3c9e6b968309d26c8622f7',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/c76215dd8612838d22ceb5e887b44db3.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7f9794a6b0e512576eb3f114d8e60ea',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/5ae8a735057250929b01e7e5d613cafc.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db3bfccf62be5b59e2a4c1636604450b',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/e44fce420c53fb3c340c8414830d17d0.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '031a959d20a3bff443ceecf6c9130401',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/1da2ff6cd23469ce88b989464be734fa.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7b95ace66210074797517ab9256a2b9',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/64be8d5b0454d403a09e4484a68dfa00.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce5ae8f3653b7bd7bf356f8d5bd1a7de',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/bbbfdc916c91b4efad2c521988576e51.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bd002612c3e3582611190b8b826a830',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/5b93a77983c9059c0c153a86e459b417.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4a784a46d60de457443390ad47a6563',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/5aee9c7a7d115da6fb22a130e776f591.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9704333ab1466f3ce0cb1ad2faf7ee04',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/402a8c986a5dd6a8478de6a89cb35d12.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c30688479f71533018d6568f962e0574',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/ca7dad4a7537049a7ef6aef9f20eefaf.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92b54ae21251c4b6c1a4227f0ef578b0',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/fbe29bd3af580d0c817a4f9f4ec89b83.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b300e53c8956b5e9735838f9f160f44',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/5de0e61e707036042406f165ebe150dc.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '765953803153ca1d841eb62a125ba702',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/96ec847023618641e0fc6ceba4e63b13.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '797710934004f7caf804f0deb4da6fbc',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/5e5c975067a4225ab61b43530e5ca0ae.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c20b6ce206f4c6969bb3fd8a850d99d',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/ebb099aea912a9671fbe12a4c849fa8d.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d3d7b0a788853897aa4d7507775f2d0',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/a4fc7044f8366b3037f1b84599eb320b.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c477781f3e242c5fb1b3e1a762223d9',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/27fff12e266b60bf12aab9a0418f3894.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b63a80f7abc5c91b18e3a9904f9203b8',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/080d4dd644f9ac6199d5ed5ed4b30f1d.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1978e784663c213f3d4767804068874d',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/b7e1bcedd9be86357d78aa21b6bdf834.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bb08ddbb94ac29b53fe74c553a6a36e',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/1632ee3d39cfacc650c71efca56b5b6e.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8fe898b7b80d29d480c68ec7489d8f2',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/5b07ddbd3f3d4b664b05843ff65f8b59.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '965fe05bf4c2cb8a581562d31d36f189',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/5250dabce64b093873f86928f0fff081.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7aecb8011b78277689723c67b42b655',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/979ffd214a529ea20178e0a920450f2c.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ae65594d95999186a2c769fe3adcd4e',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/d79e878fd78e82862986236beedb5459.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5cd0da263af8f0beadf11ce63c669de',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/fbaf25a5e27803ea66f28b077c3668eb.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e355e12e9c57bd727b14c2bf9d439b6e',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/e6e26931ad19e5e6147fe99f220e1a7d.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86b4df5a810a963dfa81ffda68b715fa',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/82c0a8cdaaaa3255ec83fc617d3609a1.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0b7c1168f46c482766f4d3220ada68d',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/3ba9dbce5e1be307a84e87767dfe63ee.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90688ae53a3beab0ee2bea0cc2dd49f2',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/04b6289496367365f159fd525e527632.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4490cd580fbe6f361fe3552421406d4e',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/d64ad8aae62a57e4d08beb97d37c90d3.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8fbf5bca9e25051cd6786e0727b23b1',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/eaae331d15998bbf265e0ccf1c47055c.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5df70e49eda7b0ed47a2cd52cf23e9b',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/db9c184f31d582ccd996aa04c596c47c.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e903fdbe62e56e8ccbc4ee2537c7b9f',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/bbb6cf489ea3a757439cb760dce57cc8.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb3e062faec881ce43a61e8cd3d4576a',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/895c3f09f4f854b162874a3173395cf4.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf022a3cbdc7ebcc7bdd2b7d3b8758aa',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/7ec56b4994c2a698874f66d472e7c045.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce13ec146e7cec5f842c5ab14888a454',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/980b775a37548d1514dbfcf088323841.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8637e4a67787102b5b043a8254fb4c2',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/1248b9fc9e0168d6d24de14e9ef61ca9.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ee21f94175f46c6e3d83773cb67ac20',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/8a454da1a7fc08078dfbb59952009950.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd19e78d31f4a36585c0c0379e3c96846',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/45c246a295c21a0f98b90f5cb36b6688.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc3fcc44b7fa0a74b2ff9b11cc72c77c',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/c19fae635ad545b5ff462cab43f14c8e.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8f3cf647899d914ab8202a6f2c54f6a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/d27aac228f9f7f9bed3c7a18f72bd455.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f44e758642fa9ce17e380f71e3de0e0',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/f2eb025173ae3db045ebed0ba0bbcac0.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff1814a4e231de33f601ab228bda1958',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/ab2cebfd58a5df0be9f27c786833e992.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '652c909d995b02bc7586f3aee536b21f',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/b7074644f548003b07a2d9ceb7f3a13f.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50f2093ae143784ff5298651968a8cd4',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/7351f3914b4bfd4ce086d2a155773f63.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7f846a5696b507a35df49159aa9712d',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/71b4426f0d5b3cc0ea62cc9f5f441189.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46017260db85e792c8af377441590675',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/3365e7325dfa56ec86073f0a3ac99a64.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbff6132666f5ba5eba294478ec583b5',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/3013c9dadd3f7cadc803128824346e70.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8d9e62aebdc2d9af808fb8fc925054b',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/f471960b0740d64de007cfae841d2411.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8b66b1004cf1b6dc1c4d938046a7415',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/1b3aac3f06037b28b3789cfbdd524283.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '952dbe1b942b136cb29a62995ed592f8',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/acbdc84071812ac2413b2c03e2770a71.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50181d4283eb65338f7e724fbe9a94ed',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/3263624c4ac30869ad332d6cf170f8ee.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf65e40df13df2918a9f1eb3f107dbef',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/4ef84c8e2c02a813e52414dc8d911f49.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '581a273a0b47cfc2adea5dcd125651ed',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/f33e228c26d7550bf61753094924946d.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84d5339e166767af6c18a73bf24c4bf7',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/7512f11ba54f56f58179cd7fdd179ae5.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5da68df27572c21214f984907b5aaef7',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/8573ada0f376fede397db85cf95dc43c.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a55bba2ff1ae5f310282202b0ebdf2e',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/50a3005cd1194562789e9f420b3922c1.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c34240346557a9c04d1d5af2a6490e94',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/d82eded7a0813d4de0a1b14b98166f7e.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a9968afc41f6d1346f78ac114ae84af',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/c1ea285e298f20f1af5511cc4f5b7d8e.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f21c5d8ef1dda83e868afabc8fe85809',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/d7827d15b147e15b2f4deb68a62eb91c.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6978f69545fad4593871a11aff0d971',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/757f38f1d3270cb59c3e15c40ef4ce21.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b1e100890a4feb7a324591fad95158a',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/11babd38e136cad7e760221ed405c906.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e55d3222ed61356c8cdab12941515a22',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/01470799073da3df2ff26e4c144d4184.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b27b846f7b9716fe26e84a68aff4d701',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/f4a2a3db3d31efc11d313bdea2059eb3.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1ec43e082cf5a54b045769abc2caabf',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/2e9c5c30fee530c0d509dae70efed6f8.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ec3916001405ffe7bf39ed7acd7bac3',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/b078c450e2da458bea51e0b5b5f46744.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14e7e99c46e30dec0a66bb28ef2d3607',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/534bb16f01557d0f2c8b67474fce04ec.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec5be23193741adecca653798f5e90b9',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/4f753e247d4e5f970b7e351079a433ef.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bffbdf3170402bfdab6c034aa1a662a3',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/ad833e3091767c8a3ca03a7065227f59.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23f685ba69c5b6c6477225eca2ee8e8d',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/1600d2318f4b2f023d01d9d3103cbb2b.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0192f267c85c83d2ef153c7ea8d6524f',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/6bd5fa01743ba60da4a1f700ebe4578c.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0a130991bd6080f1322c2dc54af4c76',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/7d6a2d731ea70234ce16ed1ab4816449.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e6dd4fc40e29f16fad5a829a8abeafb',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/84e77ddd4496a7da40bd4fe805d5fb5f.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b25018e4635fdc5046a7a9f2193be00f',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/e302714f651ee300e1ce2227768afc16.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a02527567b78675fd4db56dd5250689a',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/532efaf01a38c1bddcff7d8009e82b74.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '835c902d19b7e72b31217b580107e241',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/a291591051cd8bdb5f5118cee5e6251b.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0084fd6a8e92832f6857f410fa1eef9',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/0933cc410564191f1959616fedf954e4.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c90537aebbdbf5d4cf6e96c1a68c27c',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/e876e803019fc571711d428db7bcd482.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef6585d20c623a8ebedcb8cd0fdc345b',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/ab9d3d826a93ab0fc06cefc69240b84e.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faa89d6ded021b764c9ab5e5b37a13b5',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/c41557c1a6a6d47db3d7799c3bd764e8.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '801a28432e0c0ff20b822fb6c189f919',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/32e51d530190c6272fcfcd1db3f249ee.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d5bd382c83e44ce298fe4210809e064',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/49f8e6824a478ca0aa3213b36e5e3ac8.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1332619355834dce4fd83320665fbbb',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/52f277edde4e914ce4dfef41f76a6a0f.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5a45736529f5cfaf92ed44a40c1586b',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/e1a03fce8d206b68761754d37bba4f78.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8096ff8a8aa6e772b2d53c299253e19c',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/06cfcb78634f8dabd8b8112b38d27b04.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd14b901241b050620b24aa15003c7535',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/5ae2b1d64a43c2574578b366589d70ee.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69a914e79ef455444d9cd62d65564d73',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/c9adab50b4f930aa9e192d0c0ba5d438.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98381b99ca3c1cdb890723342bd15f6c',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/1b0729be0dd622dfa06764f8c15628bb.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea78c978b47d09e7a23fc7c988ef8ecd',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/c154375263f8c9d625f4b9519e0b17f3.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb5db415d6d9ca6bb749047dd67287b4',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/0c513cbfd54be0865572af4dcb0d6394.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a42583be1c4508e3acc17df3e9eefbeb',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/d6adec115750d53e0e1926ab598d8f65.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c81c4e9d7d140dcaff3989a5c7d40105',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/5de89bddfc5bb1b324810461e262a9a4.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c5393efe7b024dd58574a18383f9417',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/1cd53577cc99a0f8e27eb2aaf4fe1321.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b250413269674c86f41b506a6dcef67d',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/15e023b0b002561791c62ea2eb4173e4.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f19d9487fb40fe37783f1dea0445bfe',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/a408660db52d068087e822044498ee81.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57f1c14704f26b93327e82ab6481ce2b',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/cd3ed64345590d14a7be67db5d8a59c4.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12f636066060f902e320e0604290cbca',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/49d225a7d14772b1bcc160e7c7df6b55.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a475ff6b52435325c9bbceceb7a4d472',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/223c05b3aa57f2e2a8b4fe38914412c6.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ed87b2340420dba05dc84b45a6a85fc',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/92afef49885a3a372b8964ec3c5b8e1f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36823de0343ebb204d3601fc925e5c2a',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/571a2d4b1ef71eb2e36adebafc099c17.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e192132d15fe214cb912e914ddd01be5',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/69ec658f73827e5774fae6dc36c4f22e.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46a12a9489b403db4f2c2cfc982bba27',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/0a84fc09a0374ca9bed5e7ef216f2bd2.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e9b692d559a98d29f0904ea72b6d570',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/97bf6f98da46de74a5ffde7e61792660.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a5d57fa3af5a682cbb5f0692a34c316',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/42089754b380d9f47f0ef5730250a636.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a7521f291ac6b145f248fe8f914518f',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/90f8f99ef35902f722c750eaae28001e.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a082e6a1f7cfa04d80a4bd303d1bfc9',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/ee5aa65713dbcafd6274294389d312ee.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8db72b73014e3a681bc3340c4a0d1292',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/969e715087def36c0832a9277aea2474.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65a0c99bfdc7a1a6af9213ccf6e65de3',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/89adc6d49794bbff17ddf2223c9c7304.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9887d80f1d9661f6f9037b13c97ea5b',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/e290060ed28822611d7e89badbe707fc.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b638f38c6726ee7e21795e72de569668',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/867ac0d2fa2273c86d8a095014030d4f.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e93401e89cc99915c57180b6bb26ef0',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/7de410c4da3741f4a6a1a4525ad30735.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd49a8a4da3e16a6e4431db8e2ac9290',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/4db4bba452efdd49176d82d4028cd6d3.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb0c7a119175b9a90a8b531137a4dadb',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/c2b5993bbedc64841faa084989a6bc47.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53f449854667bb3fa305b948262a5f67',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/8f7d662c09dd6312e6178c21a132bb28.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17a2b14144e53bac6d939dfd53ba92cd',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/81f47b159c9a1fdb8d4adf5448665f16.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebcaa64d7c1133a5f99feb5c370f8886',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/3bd978a7222512b4394a4654b6b719f2.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d4e428e774393e6f8f59fec0f791ce6',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ed8c993876098b49d017f3a6eb2df39c.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01ff2042ed5933e837c895eace406d25',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/b8734dc58e99baede67d7ede1e34e1f4.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a47bb8484975a1087eb4858255984cd0',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/6eb4eee771ea1069f7d88a9af0947345.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5423d06186f03e6f4f09c80929363c58',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/06e2a72e3a4ee857fe1252ccbb86a775.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15571f14441e9f14687ccc00c8584a67',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/5de6d42239866218ce4e14075960f50b.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28de1d421ac800ee99814857dea95138',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/0254f84a98af32bab56ffb49b80aa996.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0739d2da9e3c46f4e6389e40339fc661',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/743c11601ee1ff9aa9a493a9d15cbdb3.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18c11b0af4dd943125288841be3f0256',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/e9c0f5f374b511341d90ee85fbf35aa3.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2062481b59bc82ff9c52a481e847fa96',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/6bd14404635b2defa5b856a3460fb369.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f4a74dca29dc53da0cb2d580b7eada9',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/b88fd457193be215b1cdf54fea6e651b.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '325aff3965e8b93400aff120875c9ea7',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/8160bcdfd70a514cd74243925d82f651.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f8cddd20959cfd8c7a676b0c0ac1ed',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/8e55c0ac240f627c10d618aac60b5e18.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86cf970a8faed354a30067c0cc9b3f41',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/29df39adf8843952ad6707a8175998c1.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb99bfc313741d556ee17c579570e5f5',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/7379927702c4a0304d2427b97ffd3963.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c394ea49cf383ec840792d3b3eeaf35b',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/71d25664f439ce460bae7288cf6fdc15.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a031386360139be45d5c566e91e997b5',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/b0f88522cd0783006ea02c4acf1b3300.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df39a012d03204d9899bdd75d3778935',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/c0c1993a628ab0bbb84906ac1dd2414d.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d42aa3d19e0d734197ac9719034e5c0',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/2a585137b608d1e21c6db547967cb44c.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ace18de23a8b2a3ee2d5ab83079fc85',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/4999588eb42f5898143cf2d6fcee7ef8.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed26cc5891a0dcd7e5f9600226fdeae0',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/b2cf053fef9e7be3478d9c81a1932494.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5b799ecae016e6a246baff8c2555d9b',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/d2c59b5ba510ea2232e1ac67e5fd3636.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51fdbee9a2e94fe3aba86efefa9db73',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/5d2abc8b302f71d6a6eae8f738296562.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dcfe31c0f32a3b6e8bfb71fe36c5427',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/35e5f0985bcefec34ab3370a09351631.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e9d0161526905cb8e1646ca4d2f31b',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/dd81eb46e976b75de8b4613c203b1458.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '682f86d81e7da32e67a6ac3ee4494fc2',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/165204e3746d4956d9a6428cd656dccd.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2e32806cb8d4e78722a933ec519612a',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/d876bd5394934c25ceab99dad73a1b84.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bae47fa8004405da15e7f6988eb1f05b',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/f83261033cf4a8179c0b803f4bd0965c.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73e4736b890d58c5438cbf34fdc28a5c',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/7f22936c51fb02f08f2fe7f6f5482a93.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a3d67d5fd6f0e70e78a8e0a13d8bab6',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/2e7d45b751adfdd5a1faa1afc9ae035a.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8aff983e525d34e56229ca64a6fe81c',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/f6129b47cdc3c12b127b34f4c3b78c79.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf35812e3c9b5030d9f5dc2500631dd5',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/ab8dea01d9fe04e80de8735acc02b0ae.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0fe741ded4690ca2609cc0eb577fd96',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/b29dfeb8b2daddf6f4bc55f596a5435c.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8ad8ede1056811202cacdfdb1c013ac',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/4ed856b9b7b5310530eec72952559533.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86636bd434b494314773962ec100d586',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/7ac55c0afaa090c276006449cbd6cab4.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af259f335957504d46d8c1fb26ecfb72',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/667cecbae350c30138ed377f3100a039.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a699d8f08679ae6facc0a6dcc8df60d0',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/577dfd2b2976c8dec6dacb30e0055c1a.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e70b95f2bc0b0d90f88bd310d8b8584',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/552aaa700f77d4a712e76bd0070b6680.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f0d49df0e170b8dd2960c32e24574c3',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/3d6deec44840c24e56a7ea153ff19477.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8aefa9cd7496c0f3506d383af15298d',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/fc982fca0c9e94c8903a680743ece209.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c46803f666099a09688b9ef1404e6c3',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/294e63162455af9d7a6722847884eed3.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e29659edbcd4a16df956e46ece7e6af3',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/ec7803dedcd2d5ebcb9f4f9058a5650f.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81b563990e0bd0e1adfb1bb4fc815c59',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/efbc5eda0abda0ec74e4a4d9d2ec2563.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27cd5da75ba7dd6d177f577e3d5e477b',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/ceb0faabca6cca6b148d68ba51cdc467.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f64ab1485cab59157d9221b795f41919',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/65ef2fcf66f037b5cb58c1bae3c50505.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '757e0d5d8a1ab4d3a81dba7f9c86c985',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/436f62fcd4dc3d2176239c7d77b299aa.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7022ae9700869e02c95a12846c91352f',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/537e7b12b6c4fd1f88ef1f6f921eb0cb.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fd46984b9fecc650e43c509d7bad482',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/ab5519079433e91aca78d9c8dc890d0a.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '056087a0d50d21d6491da95ee8e60c7a',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/641d7c66ecae941bea3e292b4050e4cd.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1810af2951e87e2c36dc5f3d35af88f5',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/31774b31de4ff84058b4a944eade108e.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8427a778020187952e12d4dfb635e7d',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/cb94f1ec37b2fc3d9c1bf00f57e4f24f.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '056549847238dc7179a2f58179b734d1',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/73ad9d9b3e4721107e15fe219e019155.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9885aa4a990e3b7137efcf92c8e83e5f',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/5167be6ddf6a8f74cfb6adc99ab79452.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bab5bfd237ccd38cdca8297966bc7b5',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/774bc63d1936464b542ad23abfeac2b8.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ff24c644e0c632f4ff0104a17828f14',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/fbefb7e20995c664803ca6a207edbc22.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8247226c0d47828b7459986f3df917e',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/e7fe8c658621dc1c678ee8de7ae9e06a.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8681068d16d961cb8c3ef61166129295',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/ccb51e90b05e1722b544e1eaf20f5ec2.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83b33613324dfc4779e5332d55bc0ac5',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/f353df7c003316b79e481d641f3871d9.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98dd4334053cb7d61485ef125abd5644',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/22c0dfe8e835359c9ec2953ba2ef4407.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb8a87e65b9172255ba4b62d980e7d58',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/feb137d33ecd0223775ae23aab2cb53e.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f467b30c1919905759abeda483e0aadd',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/2cc835105b10649441c799e8ae739b3d.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31fa86f3b1b115763f8f569299b3a910',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/35ec8ed16f69c5980239cb67e8b1d502.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '148b64fa6bfb50346fa28dcfb189f002',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/e1cb376bee2f5c3b52fdec6fb5217491.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f8beb7f86d117ee7989896aff23f06e',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/efc8a9344e3442f79c88181feff31f19.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18b7c9d800483d68dcd98ad291ea5509',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/000f18965a511c3a2fc24908000bb2fd.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a903f701d0a1937824e62f183823ed8d',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/79285d679af3e7b36bb50c0cc75eaa6a.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19c312edb32f77458444fcce40a4beaa',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/d38d2201091f785555d89c6d84b98375.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4734df534e6102fa933583dfe68e6a2',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/669e55d0804e648f33b0d4d30d3156ca.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd69068234f4103b3929a5a729983fb47',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/6aa5310387d2b4f429198be3720fa489.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8e234fac79458557efb85bb43b4e235',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/7fa08c6ad6907a098e8f7142f4e9725b.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17828f182c27819fb0a22ffc1e196ee0',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/cd674fa3ff7773418f3552362ee6c4d0.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdbc33ba0ffc09a8d6e3f962fe17440f',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/64b4d42d2c03ccf2e3dc4cf27e38a316.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16055af448c6bd1564e114bfc2e34052',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/6cd34a5285dd73ad4fe1fdf8caea862e.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8d4aa45bb2352b5597d9b5659fc2f55',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/48c0a4f1795479f2d1b42ca39aff52c5.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3880aa27e024dcc4f9a7c6832688d476',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/4692388376e6b8cb1b7ea283a50a4097.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '152ae32691b8677a6c443d64937e7721',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/c6f127ca905ddf54df0c82ecfaa56960.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de2c188a2a0324b0462b9712656fb43b',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/cc613e3c43bceb499ca2a2cc26f97189.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ac67e1952d4e3f69889b8a9012fcaca',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/156fc76271fafea306d312a38d4cfaf8.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42b2d9696e710eec066343032e8beade',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/bd54160184a58cbd8a134162a2a2c026.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc3abe2ee1db365a388c6f428e0ce23a',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/1dbdddf5c69a6e160e50e414c713d03e.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe1b2d0a7d08755dc0c13cf72ce76114',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/f9a6a8318e01d686b4e26767b87a682c.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '445cdb453d2c4818a38e2eab4b3b443e',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/a9d1d2994e9c1c149517aaf86e9239fd.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0d6613e836208a54842add25c34d967',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/64badb6453e9a7e3452c4e0cbd51385f.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9eb7e5051005f7a9b851ca84dcb3000',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/a2ef3c6833a55ccfe82c293c45c4578c.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f48cbbf030d6bcac295f1d0f9cb9081e',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/c392924c1d0d74db6a0b01c500716f93.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba2d3622926c4aa2458fd4b81b40d4d8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/bf309139e7e115415fe99707999a589c.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c078b8866cbec8914a2aba62d7cd8ae',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/bb22ee220b90491c5e660e465d775b97.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d01f0c635e3299ab5d4b969069c9a8c',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/6ac6f18714875f7a15fb4d3183fdda14.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '095e4d00556e1f240c7a2b179f42f722',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/9bde53c848cc0b156a7070b154dbe7ef.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00b4b45ead25331950c90234954794ab',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/b8bbef4876c8b2afacc0a146bfc6ddfa.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30de07f53a052723a53bf8486369ba04',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/38ed93e4b3e8e10e10571df954e8ea04.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd0a561a04dcfa765630a2fc887404a7',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/f186310dbd214866bba56497e080621c.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe157593a64df7a3b04697ded50e449d',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/515dd5cee874d03ea8a08ebc52eb829a.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20b08895e23f4f3dc1e284faffdc2509',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/35f70dca1c8dbc016e5152d97b91c9eb.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '212c2253c78f580dab2aed3b596f125e',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/9bae6a14faae946bf0699159441e24a1.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5990e09e29626b527e9367e77e017903',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/a2d552438284ad19a03e0d64b148af8d.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e25c36f0c6c8d0ab48585155d56fc630',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/290cc5191f5af7ae274fd392357cf615.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6e9850633e878df278409ea47ae6341',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/2dd695be4b409c407f9af1a65bff8f53.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd248e62329d13bfe83b24aed30b99fa',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/a3336084554257e9b35362a331fa71b7.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c8e4fa88611a37ccf13d23fa7df8700',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/c863c4f6b0490d6b876526642f066869.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa193f724ecbf8acb5259e3c9104fd02',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/99fc201ed9eb5ebfbbc01a51d996016c.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a434533f444cd0fac53c9e5ab312b0cd',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/f1098e9951ee13ebb1c48461278f351e.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b84ff15dc4896439d234aa5146087b9',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/281f402b4df9bd684cced9deb583bc13.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccb9fb8a6fbc9976326132331f5af4b4',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/5f1398cfafc3670a611932b8d6bfb20e.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '050dcc2f0ee51c8cf3acb204de59cd00',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/e30be234619ef740a0aea9f1a4fa1beb.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '769a33d340baaea5003d956d9059b58f',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/19c3b28aacbd4b32318e789b96833430.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99550316e975acc2eb169ec09b0467c2',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/f22bfb5e75332e659f9d9e86ad8cafdb.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4468ed0996fff91e80e9575c1f0cade4',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/2d0f85f42a81c3c5077edde70851bbea.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49536b5d293d033fbf9925152a9ab383',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/577d0ae5d55a08238932ba1c7e6c63a7.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fbd9ebf0937c60a8285a74557b38f2a',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/d67c0069d3c6d95a366e9021659087d1.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dcd71871553c4576232bc9c544ca331',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/93e33ccb983a7f2a4c9ec31f084e0fcd.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc59a3eeec261ce9a037cb30a6da49e',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/6b204f77b7bf6cba362da7a09bfc8522.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2d7ddfbec23f85ca55810c68398b933',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/7288947ba734579bce9c996d94003bbc.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2533ef68f8caf7be8b326846c6a1ef89',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/eae0f8983955b36baa095376820c4c4e.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc97f43ef01fb5187d7109ab62ba8d75',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/b15a5cf0fdbd431c33b17883321e05a9.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5280e18148593775cd7b1d550a44945d',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/51a7790a6ec8e66ff03816cea95c2fc2.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f8382e1927db70d809391613bcbbb33',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/7631b31266845bc8959dbe0686f026bf.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3c110681b6637c1a3fb261e9cd6e481',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/102815893fb9302cbde4c43d8a8b80c2.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f00402996515b3f11f842ccc79b86a15',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/933f4ccf82975c330e78b9ca9d1e711e.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f7159f43a66171308bf160c6f6cedfa',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/a45597f15f44b3aabb46b5f159eae0ee.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '821a7d417de5b790d7149bbcdb7d3871',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/d717b5598990be815eb58294dae301cb.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d6ce26684b82cfccc451857b55e0b0e',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/f323b3aaf0ba3206efbfb8393e487b1b.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '523a41c61dd04072c73cb0159ddf2929',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/f12fda8c1270ffea2233c991ea0841bb.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08477f75853d68feda3abb176901d136',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/a214632aeb3c29a7461aa3ad4ff7c663.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8ef42aa4e00e0a5029189d97058e4c5',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/7534511a0333592dd53c31574521af25.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00cd1cfa6a697d620d76dd8f6f5722a7',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/508bd5a4a23a7af4192354104c53f26f.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cec0a5c9c7fd9afd114dff5f8918cc5',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/171fd46a3bced16de16abcaac00e465d.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ad5dbe93579e099fa7117b199d575d5',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/9dda4844b6f9342a523a368d2e46d9a2.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87d080fe1eb0c7cab617702502d15836',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/e4610b67c915519e8f9e0098f309959b.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7550390b462f412ad9d69ba953e99de8',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/d1c7e69c9610213d988b5fa1d9377186.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59a7b49f9c8387af7bbc3dc482fe1ca6',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/da15752924dcaaf7630cc77b7c14fa10.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '846319c052622090fd08bddd6fb972b7',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/81c8ceeacc1439426513242091762211.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a378bc35e8948145fec77ec4d0a740c7',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/ebcf5957ea3ab5df073e7b1016c032b3.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '988b0fd4accb120d2f8138dcdcd86915',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/c913991297404520e1826bf7b5fbcfb7.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f162ad9a8bf947fccf6fde545fb16cd9',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/a4193e7c3b2a692f607917957c016333.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '374a9860f55cb144c1d824aa57b06609',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/861f8a66d1f35371b807b72491affe1c.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b39c6cc59f5ac350696cdaa5efa0563',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/acbc8b37cb2e509f49e57ba9f9234ade.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a636b9f7897718e6689a3c8aa45c7ea',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/3d8a38512e516106e266d3b8c6ea94d7.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3ccead88435ca035c64f21c7f925454',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/1dbae8eefec4b320af9640a1eba8072b.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edfdf29857e5e225fa186ace364dbafb',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/c224e7c1275e3ceeae6cbc688f28c708.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9518a422decfb7548f95de61aff2d2fe',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/320acbebff3bc4a32784e6e73866034a.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8671d7dc5a575c827b2d4da2ecd2ca68',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/17a76ec5752e1e7b53e1aadb73abfedf.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b184615861e7d445dec4625b9ff3409',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/a98b26637cff621c328b251dcaa26790.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe7794562684d331e24e03a4335b63cf',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/1c5da694889d94c132020c5a3b2609d0.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5ad031e53faff832559886fa320f78b',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/e6b215e35e16d01dfb7273432e5785ed.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a949f160be3ffa71f8f11993dfe5e6b',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/a4551e3bea444feeff0fe0bd4a724853.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acc33c2f156677cba24372aff792245e',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/d5cb9d29fd61cde0a87a6215c3af6751.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf8c1cdd7223fd2af04356a38189b3d2',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/feca573003b30a60869dac66d27680ed.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c69d18b48c7a8d984d470106c4f1b7b4',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/8b4cfc675e99f75e0eebd9680692e088.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4eedc3c084c0eb375a118e930490f69',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/280815cc49b3bcfe3b66455ae026964d.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e7d4dfcc0869ca7aff4461c1d31f5c1',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/0c2dd73c8ecebf2297276d2c6c36ad69.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74fae0efcfbe2cb41543b43749da7a20',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/49a456cd7a4939fd98355b8c5f843e44.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dba1bcbb55e48ee1cf17b1790325249d',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/215f26866374b92ea775cf307aad8e05.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79c6a7dbc058fc26b3cdc17a056775aa',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/f3bcf94ec34dc2cb8630da9de944b210.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27219e5fb02eb06bf132c741d6a27d18',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/9aa6f4b476629ae4ee828600c65aee54.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7a93803c1a182186136e214ea38f4b3',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/0675424e5e2a53d7e68b79ae368d619c.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54ba0aed25de8ee96202a8d358620ac8',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/737b9b1c0aff2dd9c249b86180fde574.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd70c1c9c8596e571160e3ef8aa8e9a18',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/3cdb6911106eb7909e43ba44f7a93b20.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '117a5356f5743805a5cb4406dda9af72',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/6fd50c186ba16005f4d70812ca2a188e.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f88985907552e3dce8bf63dd19891511',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/e2e08d6ad54ecd2c6cbae94e71906569.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4405210905c72579ac241a0b7d003133',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/e0c4c5103603eee5a821d293ddc13494.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1a9e2e2817746da46612af6127a1e80',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/018cd6b2b5ea4d397fb73541553b8bbd.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e41b28a917cf278947db517bc1cb7490',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/87be5f0d24b214de691b31b799827d9b.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '985c172abc4f1053e765f06d556b689e',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/63e8c8723c75ddbf5b3bad00d8da9cf2.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42534fff04363973e5d1e1466adf773d',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/80cb9df00adf42a616886695b11e060f.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd96ec4855aea49eee0d45881f97f679b',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/159287a2156f9f7d4d2b1171f8d1343c.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2640c0b05caecd220e1ddda65b73f81a',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/10c02f3f81d1a168ecc19bb4d4964746.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c15759565e1107117fad39634878e5ff',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/2a4cacfd44b7624b5948f9ec3ba66ee5.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48c53fc64a25d66e88983b2806b7c8ce',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/e7c2d6d0ce8b2b0f95dc62e1af63062c.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83e48d4af0999768e1e53534b8fc6b55',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/d24313768dd6bc1b7da0dfd701f38c9f.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec3be53c883f7e14ca80b5346f6ec51e',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/7461964de5913aa4b0fc4059bfcb4177.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3b8adf8dc000ec98eaedb77d4485e5',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/30b9c47a69feb8350df3ab9ae991b394.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64034a97d048c519f5e298bce8c55104',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/d4935b12f03edeeb259c9c66bad8004c.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a9a6a95f6f56b5c6a98818d47a7c951',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/b012390ece79a2aed7d1d963a384699b.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fbe6d8e364600350f61d100b1cc1bae',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/e287e339f15374f46fd100f5d99780e2.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98062d90f2fd416cf42d0256451b76a9',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/752469446ea34f9399e31680c5c90b41.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0159a44f2f82b5b98ef5824b803bcf3',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/a2b7bf0cc01bcb9f7df7c95579232a82.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf194fb2bc226119369dd53d919611ac',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/924ff4a3f59e30848192abc4a88c7460.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cbb9ef69d65366006b8431640fdb627',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/aebe298d0bb2962cb429187cb038839f.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c80d052864fbbc6e52044e62d51f8570',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/25fb266e46bc8b77613af5c0056f8f82.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c994e89177139c6f897826e28e21f65a',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/3637010f300ebdcf24257e6a0346964e.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a1fc8a67b22829e9d6977f8e4187373',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/83cc978aac5b9d4966eb6af4055f7416.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ace654eac1af8ecd802c677f03b107dd',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/f4b260a96c38b53a085c176bb35878a1.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e90f9af46382eec4c767a1ec55702728',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/1e96a559f8d06b356f7abde46e732b0f.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae9d2c44276c9d976df75de947f33d0f',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/0c8e4d7f0b42d9e92d34ed5f80618f41.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41a8d6e46530a0fb1dca66447e87ba9d',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/b46049c0c7eed699a6df33d08ac67a16.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfb1b63d7f44ac988f6b3e3315c03fcd',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/0263929a5fe2c5e5ec96fee6a22262c8.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f391c2b5cb539d9d564550983857bdd',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/28af9ea8fed3c96d34bfe0c64ef24cd3.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c68b7ab46f80bf0f0667621c10a530be',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/3d25c18111f57c9d60f1d610aab25c72.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c59e0bf21dc47459257c8bcd82a003bb',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/527b31bfdf357ab5ea7ed77aef248813.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'da5674112b6f2c097ea121dc67c2c64c',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/3d2a8e3c83ee2dd6ee4b1bd5a60aa27a.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '579133ab7c6ab5c42f30fbb2e863163d',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/8beaf3f7b3eef4056bf85152f1dd5758.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'e3d12ae2b00c97114c156ccb9aa9edd0',
      'native_key' => 1,
      'filename' => 'modUserGroup/ec417602b9d257da53b0e1f380b8ab18.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'fd068a893ec3540cad61371922779139',
      'native_key' => 1,
      'filename' => 'modDashboard/0918a97cb346a1ef6f42820ae73c2a44.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'e419a481c1d738151dff2733248cd85e',
      'native_key' => 1,
      'filename' => 'modMediaSource/b400b54c7d3c0d187c164a38a2ec48bd.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3057f449315663b777708c799d46eb44',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/49d7152abe4cabcaeebd4e7bbae1d76c.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ee9621297918dc1a7ebd7e95fb874d1a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/35f23f69cb4231fbc84a57664685ad89.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '26b7b55f5f131260a9a242af55e123a1',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/230a7118fb9e660d56b02d69ca012d97.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '1d42b1aa521362438cba9d60bba7cc06',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/48aaf26c90c67a8996fe912d382186c5.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f161fa938f1c79e6c3b2ed91a88c14b4',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/05cc6cdf92f805c4db990ca71fae9aca.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'cbbd920fa8e95a9917a37ba2672bc43a',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/9d6736d8aa3fac8ef2c85ef196776919.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'edf2bb727697e3bcba5d7ec139694aaf',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/743cbbc25e4285401a7cbc7e38200b6f.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7fdc9c2ab27bbbd954043cd6e5255226',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4401db05269ceec34d0bae2169d7e705.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '384e7441a6ec65abd111e0d1789bf547',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/66c5e46608fde7259ed8769a476c6313.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '10ee927598af05269f9a28d9c247236f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7c04ace349539f67bd8434cf3e553aea.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4d7d063219d78a6dc11130e01d0d21e1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3cf4aaee9bd03f2c53633d7038463c35.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd034ee9324a96ece7cbd6c93df0275ed',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b49528ddf27463a4ee09ab2c17b6e8cd.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '391b09444da23e302d2c1606db554e08',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8ce666a60ed31071b6276ca1e15e2596.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2e40151cd06e213eef0b5a10e178e36c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a5d05922dc8d527eb82b37d02cea3f72.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'fb0836782a017b4c19511c0b9e260348',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c31f04642d704599e9932ae37581f0bc.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ff3750e19147c1288de03772849fd807',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b05015c40a9af131c16167473f757d0e.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '79f94eed2f19f41adedc5701fb19668f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5a9efd8e5861b2d817028687b2a7da9e.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '164260c1bd4c192a3ad1ee7da58994b9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0e9b916ffd7162f4851bc36163e0a06d.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '70ab2451c8188ecfe6c6297977be26e4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bca91ea44e69d776cb80411e4ac3e693.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7a86bb520d04c736ddb17be076228009',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9f9083df83eb88b1fe6170fb57c2a23a.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f64c809aaa37f36c1eb4fb29b594526f',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/1d25ebabc6ce6892ee224688efb7c51f.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bd99cd98a55f3cb4e22e5b642576866b',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/bd6038e92d3b2a3b1e85575f1380190d.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b3367690d4aacc00525982e3546bc774',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/ad6c3e7dd5e998efffedb97087333590.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7cf399a8d4a1e4fc8af0951e9bbc6424',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/a12b5f72a4969881132ca234d7f4525c.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '12643a96d103c9c3ecddd7bb1541ae14',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/6e6b09739666eeffa276d5b6219bb1bb.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '801675109c34ba04112b538e3563c341',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/f504948d2b13e3eaed88f29bfd951e08.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd4b84293b8cd239c2c8ecb7c054c390f',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/bb1129ce0bb329fc13f27ce7988379b1.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1c30f3703d5f36ee426aa4742a438ebb',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/58eed560dd5e22ff3636f36ec51dc000.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c8ed4588d2637e2fc6480dbf913b03d5',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/8e5db44e82f31e63bdb8627d0556874c.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '15948c1a99d70b1425342237759adb8c',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/68e93c03f7dfc97e94cc135c8a110fe7.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0b38141575641a1b679b5114f6e709c7',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/fb79d85db25aeaa3b90d24ab6e3b07d4.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '50331cbd3be9e02d7430b81df7a70759',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/8aca2f68ed620b4ee8c5ff19f93cc9c5.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '98dd16f6efd6520e4b919704645cd2a1',
      'native_key' => 'web',
      'filename' => 'modContext/da9ebb7c9eaba1a42648ec5933d13afb.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'cd168a277f361e7e048f8f1c4032b5cb',
      'native_key' => 'mgr',
      'filename' => 'modContext/c8d7691f4f62902521b41c375155963f.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9d922d2db9729881dfb04b16f1836c20',
      'native_key' => '9d922d2db9729881dfb04b16f1836c20',
      'filename' => 'xPDOFileVehicle/c31025c2565eb475fe8ed40ef647dae7.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '99eb2391f1270da6abb79a17637fc2d6',
      'native_key' => '99eb2391f1270da6abb79a17637fc2d6',
      'filename' => 'xPDOFileVehicle/73e4e286998fbd67dc6af7e74210dad0.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '47c047131a9398988eb51ec61562c04e',
      'native_key' => '47c047131a9398988eb51ec61562c04e',
      'filename' => 'xPDOFileVehicle/8d71adbe2039ec8c06a32e816a5153ed.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fdd33c060d7988bc2ec7e0882c25c346',
      'native_key' => 'fdd33c060d7988bc2ec7e0882c25c346',
      'filename' => 'xPDOFileVehicle/e72072ea8e6b00135ac2f27b60058a32.vehicle',
    ),
  ),
);